<?php

/* Ici nous supprimons un enregistrement de la table users et redirigeons l'utilisateur connecté vers la page d'administration */

require 'inc/db.php';

$id = $_GET['id'];

$req = $pdo->prepare('DELETE FROM users WHERE id = :id');

$req->execute(['id' => $_POST['id']]);

$req->closeCursor();

header('Location : administration.php');

?>

