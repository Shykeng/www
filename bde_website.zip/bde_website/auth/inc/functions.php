<?php

/* Fonction permmetant de visualiser les données stocké dans une variable */

function debug($variable){

	echo '<pre>' . print_r($variable, true) . '</pre>';
}

/* Fonction permettant de générer un token de manière casi aléatoire */

function str_random($length){

	$alphabet = "0123456789azertyuiopqsdfghjklmwxcvbnAZERTYUIOPQSDFGHJKLMWXCVBN";

	return substr(str_shuffle(str_repeat($alphabet, $length)), 0, $length);
}

/* Fonction limitant l'accès à la page account.php seulement si l'utilisateur est connecté */

function logged_only(){

/* Démarrage de la session */

if(session_status() == PHP_SESSION_NONE){

session_start(); 

}

/* Si l'utilisateur tente d'accéder à la page account.php sans être connecté il est alors redirigé vers la page de connexion */

if(!isset($_SESSION['auth'])){

	$_SESSION['flash']['d'] = "You are not allowed to access this page !";

	header('Location: login.php');

	exit();

	}
}

