<?php 

if(session_status() == PHP_SESSION_NONE){

session_start(); 

}

?>

    <div>
        
      <?php if (isset($_SESSION['auth'])): ?>

      <li><a href="logout.php">Déconnexion</a></li>

      <?php else: ?>

      <li><a href="register.php">S'inscrire</a></li>

      <li><a href="login.php">Connexion</a></li>

      <?php endif; ?>

    </div>  
      

    <div>

      <?php if(isset($_SESSION['flash'])): ?>

        <?php foreach($_SESSION['flash'] as $type => $message): ?>

        <div class="alert alert-<?= $type; ?>">

          <?= $message; ?>

      </div>

        <?php endforeach; ?>

        <?php unset($_SESSION['flash']); ?>

      <?php endif; ?>

    </div>