<?php

/* Ici nous allons définir une requête SQL permettant de modifier un enregistrement et redirigeons l'utilisateur connecté vers la page d'administration */