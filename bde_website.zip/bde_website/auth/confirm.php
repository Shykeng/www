<?php

/* Récupération des variables super globale */

$user_id = $_GET['id'];

$token = $_GET['token'];

/* Connexion à la base de données */

require 'inc/db.php';

/* On sélectionne l'utilisateur correspondant à l'identifiant demandé */

$req = $pdo->prepare('SELECT * FROM users WHERE id = ?');

$req->execute([$user_id]);

/* On récupère l'enregistrement dans la varibale $user */

$user = $req->fetch();

/* Démarrage de la session */

session_start();

/* Si un utilisateur et un token correspondent au résultat de la requête alors l'on met le token à la valeure NULL puis on met la date dans la colomne confirmed_at dans notre BDD puis enfin nous redirigeons l'utilisateur sur la page account.php */

if($user && $user->confirmation_token == $token){

	$req = $pdo->prepare('UPDATE users SET confirmation_token = NULL, confirmed_at = NOW() WHERE id = ?');

	$req->execute([$user_id]);

	$_SESSION['flash']['success'] = "Sign up successful !";

	$_SESSION['auth'] = $user;

	header('Location: account.php');

	/*	Sinon nous renvoyons une erreure et redirigeons ainsi l'utilisateur sur la page de connexion */

	}else {

	$_SESSION['flash']['danger'] = "This token is no more available !";

	header('Location: login.php');
}
