<?php 

/* Si les champs dans le formulaire ne sont pas vite nous nous connectons à la base de données et récupérons les enregisrements */
  
if(!empty($_POST) && !empty($_POST['username']) && !empty($_POST['password'])) {

	require_once 'inc/db.php';

	require_once 'inc/functions.php';

	$req = $pdo->prepare('SELECT * FROM users WHERE (username = :username or email = :username)');

	$req->execute(['username' => $_POST['username']]);

	$user = $req->fetch(PDO::FETCH_OBJ);

	/* Si le champ pseudonyme et le hash du mot de passe saisi correspondent à un enregistrement dans la base de données alors nous démarrons une session et redirigeons l'utilisateur vers la page account.php soit son compte */

	if($user && password_verify($_POST['password'], $user->password)){
		
		session_start();

		$_SESSION['auth'] = $user;

		$_SESSION['flash']['success'] = "You are now connected !";

		header('Location: account.php');

		exit();

	}else {

		$_SESSION['flash']['danger'] = "Invalid login or password !";

	}

}

?>

<!DOCTYPE html>

<html lang="fr" id="background">

<head>

   <title>Connexion BDE</title>

  <link href="../assets/css/default.css" rel="stylesheet">

</head>

<body>

  <div id="form-center">

    <div id="form">

      <h1 id="title">Connexion</h1>

        <form id="connection" method="POST">

          <div id="input">

          	<input class="input" type="text" name="username" placeholder="Pseudonyme">

            <input class="input" type="password" name="password" placeholder="Mot de passe" required>

            <div class="center-link">
          		<a href="register.php">Pas encore de compte ?</a>
          	</div> 

          </div>

			<!-- Ajout du type d'utilisateur via un input de type radio -->	

          	<!--<div id="radio">

            <label>
              <input class="radio" type="radio" name="choice" value="student">Étudiant
            </label>

            <label>
               <input class="radio" type="radio" name="choice" value="member">Membre
            </label>

            <label>
              <input class="radio" type="radio" name="choice" value="admin">Admin
            </label>

          </div>-->

          </div>
    
          <div id="submit-center">
            <input class="button" type="submit" name="login" id="submit" value="Connexion">
          </div>

          <div class="center-link">
            <a href="../index.html">Accueil</a>
          </div> 
  

        </form>

    </div>

  </div>

</body>

</html>