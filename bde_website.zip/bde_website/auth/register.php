<?php

require_once 'inc/functions.php'; 

session_start();

/* Si le formulaire n'est pas vide */

if(!empty($_POST)){

	require_once 'inc/db.php';

	$errors = array();

	/* Si le champ nom d'utilisateur est vide ou bien qu'il ne respecte pas l'expression régulière (ici "N'importe quelle lettre majuscule ou minuscule ou bien n'importe quel chiffre ou bien un underscore" ) alors le pseudonyme est invalide */

	if(empty($_POST['username']) || !preg_match('/^[a-zA-Z0-9_]+$/', $_POST['username'])){

		$errors['username'] = "Your pseudonym is invalid !";

		/* Sinon nous vérifions que le nom d'utilisateur n'est pas déjà pris */

	} else {

		$req = $pdo->prepare('SELECT id FROM users WHERE username = ?');

		$req->execute([$_POST['username']]);

		$user = $req->fetch();

		if($user) {

			$errors['username'] = "This pseudonym is already taken !";

		}

	}

		/* Si l'e-mail correspond au standard d'une adresse mail en outre si l'e-mail saisit est bien une adresse mail */

		if(empty($_POST['email']) || !filter_var($_POST['email'], FILTER_VALIDATE_EMAIL)){

		$errors['email'] = "Your email is invalid !";

		/* Sinon nous vérifions que l'email n'est pas déjà pris */

		} else {

		$req = $pdo->prepare('SELECT id FROM users WHERE email = ?');

		$req->execute([$_POST['email']]);

		$user = $req->fetch();

		if($user) {

			$errors['email'] = "This email is already used !";

			}
		}

			/* Si le champ mot de passe est vide ou bien qu'il ne respecte pas l'expression régulière (ici Au moins une lettre minuscule, au moins une lettre majuscule, au moins un chiffre) et Si le champ confirmation du mot de passe est vide ou bien qu'il ne respecte pas l'expression régulière (ici Au moins une lettre minuscule, au moins une lettre majuscule, au moins un chiffre) alors le mot de passe est invalide */
		
			if(empty($_POST['password']) || preg_match('/[a-z]+/', $_POST['password']) && preg_match('/[A-Z]+/', $_POST['password']) && preg_match('/[0-9]+/', $_POST['password']) != preg_match('/[a-z]+/', $_POST['password_confirm'])){

				$errors['password'] = "Please enter a valid password !";

			}

				/* S'il il n'a pas d'erreurs alors nous insérons les données de l'utilisateur dans la base de données puis nous confirmons sont inscription en renvoyant le token au fichier confirm.php qui n'apparaît pas pour l'utilisateur ce dernier renvoyant lui même à la page account.php*/

				if(empty($errors)){

					$req = $pdo->prepare("INSERT INTO users SET username = ?, password = ?, email = ?, confirmation_token = ?");

					$password = password_hash($_POST['password'], PASSWORD_BCRYPT);

					$token = str_random(60); 

					$req->execute([$_POST['username'], $password, $_POST['email'], $token]);

					$user_id = $pdo->lastInsertId();

					$_SESSION['flash']['success'] = "Sign up successful !";

					header('Location:confirm.php?' . http_build_query(array( 'id'=> $user_id, 'token' => $token)));

					exit();

				}


}


?>

<?php 

/* Si aucune session n'est active nous en démarrons une */

if(session_status() == PHP_SESSION_NONE){

session_start(); 

}

?>

<!DOCTYPE html>

<html lang="fr" id="background">

<head>

  <title>Inscription BDE</title>

  <link href="../assets/css/default.css" rel="stylesheet">

</head>

<body>

  <div id="form-center">

    <div id="form">

      <h1 id="title">Inscription</h1>

        <form id="connection" action="#" method="POST">

          <div id="input">

            <input class="input" type="text" name="username" placeholder="Pseudonyme" required>

            <input class="input" type="email" name="email" placeholder="E-mail" required>

            <input class="input" type="password" name="password" placeholder="Mot de passe" required>

            <input class="input" type="password" name="password-confirm" placeholder="Confirmation du mot de passe" required>

            <div class="center-link">
          		<a href="login.php">Déjà un compte ?</a>
          	</div>  

          </div>

			<!-- Ajout du type d'utilisateur via un input de type radio -->	

         	<!--<div id="radio">

            <label>
              <input class="radio" type="radio" name="choice" value="student">Étudiant
            </label>

            <label>
               <input class="radio" type="radio" name="choice" value="member">Membre
            </label>

            <label>
              <input class="radio" type="radio" name="choice" value="admin">Admin
            </label>-->

          </div>
    
          <div id="submit-center">
            <input class="button" type="submit" id="submit" value="S'inscrire">
          </div>

          <div class="center-link">
            <a href="../index.html">Accueil</a>
          </div> 
  

        </form>

    </div>

  </div>

</body>

</html>