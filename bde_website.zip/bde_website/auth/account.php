<?php

require 'inc/functions.php';

logged_only();

/* Si le formulaire en'est pas vide  */

if(!empty($_POST)){

	/* Si les mots de passes ne correspondent pas on renvoi une erreur  */

	if(!empty($_POST['password']) || $_POST['password'] != $_POST['password_confirm']){

		$_SESSION['flash']['danger'] = "Passwords do not match !";

		/* Sinon l'on effectue la mise à jour du mot de passe de l'utilisateur */

	}else {

		$user_id = $_SESSION['auth']->id;

		$password = password_hash($_POST['password'], PASSWORD_BCRYPT);

		require_once 'inc/db.php';

		$req = $pdo->prepare('UPDATE users SET password = ?');

		$req->execute([$password]);

		$_SESSION['flash']['success'] = "Your password has been successfully update !";

	}

}

?>

<!DOCTYPE html>

<html lang="fr" id="background">

<head>

  <title>Votre compte</title>

  <link href="../assets/css/default.css" rel="stylesheet">

</head>

<body>
	
	<h2>Compte de <?= $_SESSION['auth']->username; ?></h2>

  	<div id="form-center">

    	<div id="form">

        	<form id="connection" action="#" method="POST">
		
				<div id="input">
					
					<input class="input" type="password" name="password" placeholder="Nouveau mot de passe"/>

					<input class="input" type="password" name="password_confirm" placeholder="Comfirmation nouveau mot de passe"/>
							
			        <div id="submit-center">
			           <input class="button" type="submit" id="submit" value="Ok">
			        </div>

			</form>

			<div class="center-link">
				<a href="administration.php">Page Administrateur</a>			
			</div>

			<br>

			<div class="center-link">
				<a href="signout.php">Déconnexion</a>			
			</div>

       	 </div>

	  </div>

</body>

</html>



