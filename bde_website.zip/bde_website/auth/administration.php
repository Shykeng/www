<?php

/* Nous effectuons une reqête SQL permettant d'afficher les enregistrements de la table users */

require 'inc/db.php';

$req = $pdo->prepare('SELECT * FROM users ORDER BY `users`.`id` ASC ');

$req->execute();

?>


<!DOCTYPE html>

<html lang="fr" id="background">

	<head>
	
		<title>Interface d'administration BDE</title>

		 <link href="../assets/css/default.css" rel="stylesheet">

	</head>

	<body>

		<h2>Liste des utilisateurs :</h2>

		<!-- Nous definissons un tableau dans lequel nous affichons chacun des enregistrements de la table users -->

		<?php

		echo '<table>';
		echo '<tr>';
		echo '<th>'."Identifiant".'</th>';
		echo '<th>'."Pseudonyme".'</th>';
		echo '<th>'."E-mail".'</th>';
		echo '<th>'."Mot de passe".'</th>';
		echo '<th>'."#".'</th>';
		echo '<th>'."#".'</th>';

		while ($data = $req->fetch()) {

			echo '<tr>';
			echo '<th>'.$data->id.'</th>';
			echo '<th>'.$data->username.'</th>';
			echo '<th>'.$data->email.'</th>';
			echo '<th>'.$data->password.'</th>';
			echo '<th>'.'<a href="edit.php?id='.$data->id.'">'."Modifier".'</a>'.'</th>';
			echo '<th>'.'<a href="delete.php?id='.$data->id.'">'."Supprimer".'</a>'.'</th>';
			echo '</tr>';

		}

		echo '</table>';

		$req->closeCursor();	

		?>

	</body>

</html>